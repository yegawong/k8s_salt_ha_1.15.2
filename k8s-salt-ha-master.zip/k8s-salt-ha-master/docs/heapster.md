## heapster部署

### 部署heapster组件

```
[root@linux-node1 ~]# kubectl create -f /srv/addons/heapster/

```

### 登录Dashboard查看

 登录Dashboard即可查看到对应的监控图表。
