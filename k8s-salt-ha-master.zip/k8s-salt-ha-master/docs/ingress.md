## 部署 Traefik

```
kubectl create -f /srv/addons/ingress/
```


## Traefik Dashboard

  ![架构图](https://github.com/unixhot/salt-kubernetes/blob/master/docs/ingress.png)
